// site-config.ts: Central configuration endpoint for TikTube Tools production deployment

// Safely evaluate env variables in both CommonJS/ESM Node server environments and browser Bundlers
const getEnv = (key: string, defaultValue: string): string => {
  if (typeof process !== "undefined" && process?.env && process.env[key]) {
    return process.env[key] as string;
  }
  // Client-side fallback using Vite's prefixed variables if available
  // @ts-ignore
  if (typeof import.meta !== "undefined" && import.meta?.env && import.meta.env[`VITE_${key}`]) {
    // @ts-ignore
    return import.meta.env[`VITE_${key}`] as string;
  }
  return defaultValue;
};

export const SITE_CONFIG = {
  DOMAIN_URL: getEnv("DOMAIN_URL", "https://TikTubeTools.com"),
  SITE_NAME: getEnv("SITE_NAME", "TikTube Tools"),
  WORDPRESS_URL: getEnv("WORDPRESS_URL", "https://TikTubeTools.com/blog"),
  WORDPRESS_API_URL: getEnv("WORDPRESS_API_URL", "https://TikTubeTools.com/blog/wp-json/wp/v2"),
  ADMIN_EMAIL: getEnv("ADMIN_EMAIL", "aerogaming.2023@gmail.com"),
  
  API_KEYS: {
    GEMINI_API_KEY: getEnv("GEMINI_API_KEY", ""),
    OPENAI_API_KEY: getEnv("OPENAI_API_KEY", "")
  },

  ANALYTICS_SETTINGS: {
    TRACKING_ENABLED: true,
    POLL_INTERVAL_MS: 5000,
    DB_FILE_PATHS: {
      VISITS: "uploads/analytics_visits.json",
      EVENTS: "uploads/analytics_events.json",
      STATS: "uploads/analytics_stats.json"
    }
  },

  DATABASE_SETTINGS: {
    PROVIDER: getEnv("DB_PROVIDER", "filesystem"), // fallback filesystem for container state, can be loaded with Postgres/Cloud SQL credentials
    HOST: getEnv("DB_HOST", "localhost"),
    PORT: Number(getEnv("DB_PORT", "5432")),
    USER: getEnv("DB_USER", ""),
    PASSWORD: getEnv("DB_PASSWORD", ""),
    NAME: getEnv("DB_NAME", ""),
    SSL: getEnv("DB_SSL", "false") === "true"
  }
};

export default SITE_CONFIG;
